Created by Kyle Kilbride
For Science Fiction Elective at Algonquin College

Known Bugs:

- do not click anywhere on the page, just type the number or words
  you wish to use and everything will go great!

ENJOY THE GAME 

LINK TO GAME: http://profchris.com/kylekilbride/Final%20Project/